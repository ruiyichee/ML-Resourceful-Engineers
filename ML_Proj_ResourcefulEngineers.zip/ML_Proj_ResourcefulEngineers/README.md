# ML-Resourceful-Engineers
This project is part of 01.112 Machine Learning module. We are a group of undergraduates majoring in Engineering Systems and Design.

In the codes, there is os module which provides a way of using the operating system dependent functionality. The os.chdir() function is used to change the current working directory to the given path, which is useful when we wish to have the output files to be in the same directory as the input files.

Please be sure to add the below paths to the files before running the code. The paths codes can be found on the bottom part of the python codes.

os.chdir('./EN')
dirEN_train = './EN/train'
dirEN_in = './EN/dev.in'
dirEN_out = './EN/dev.out'

os.chdir('./CN')
dirCN_train = './CN/train'
dirCN_in = './CN/dev.in'
dirCN_out = './CN/dev.out'

os.chdir('./ES')
dirES_train = './ES/train'
dirES_in = './ES/dev.in'
dirES_out = './ES/dev.out'

os.chdir('./RU')
dirRU_train = './RU/train'
dirRU_in = './RU/dev.in'
dirRU_out = './RU/dev.out'


Members: Chee Rui Yi (1001738), Maylizabeth (1001818), Regina Lim (1001789)
